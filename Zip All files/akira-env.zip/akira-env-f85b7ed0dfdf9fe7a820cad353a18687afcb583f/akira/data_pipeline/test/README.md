# Docker Image Testing Strategy
1. Runtime test
2. Docker image staging test