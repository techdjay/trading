# Currency Return

# Spot
# Strategy:
# position,
# placing position in USD, using the rate the order has been place
# AUD, NZD, GBP, EUR
# AUD/USD_{t} -> amount in USD
# our position become AUD, which in our account
# now AUD/USD_{t+1} become AUD/USD_{t} * R
# USD/AUD_{t} USD/AUD_{t+1}
# USD/AUD = 1/R
# AUD * R
# short USD * 1/R

# Forward
