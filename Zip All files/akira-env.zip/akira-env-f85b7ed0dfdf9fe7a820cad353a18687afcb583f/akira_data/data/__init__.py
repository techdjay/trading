import abc
from .web import InvestingDotComAPI, EcoEventAPI
from enum import Enum