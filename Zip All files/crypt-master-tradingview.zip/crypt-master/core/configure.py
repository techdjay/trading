import queue
import json
config = {}
dog = {}
q = queue.Queue()
fuckdict = {"fuck1":1}
with open("./config.json") as f:
    config = json.load(f)

