
import cryptocompare as cryp
import datetime
from core import DBUtils

from core.configure import config



# data = cryp.get_coin_list(format=False)
# print(data.keys())

# print(cryp.get_price("BTC","USDT"))
# data = cryp.get_historical_price_day('BTC', 'USDT', limit=24, exchange='CCCAGG', toTs=datetime.datetime(2019,6,6))
# print(data)

1440
# cryp.get_historical_price_hour()


