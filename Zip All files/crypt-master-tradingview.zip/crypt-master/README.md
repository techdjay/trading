# tradingview-scraper 2020

## Install imports
```
pip install -r requirements.txt
```

## Run
```
python main.py
```
