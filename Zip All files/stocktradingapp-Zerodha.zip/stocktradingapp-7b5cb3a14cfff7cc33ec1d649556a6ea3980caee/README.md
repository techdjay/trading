# kiteconnect-Bypass
steps:
1. Update userzerodha.json file with your login credentials
2. Paste your code in 'script.py's main1() function.
3. add python and TA-Lib buildpacks from 'Heroku Buildpacks.txt' to heroku app.