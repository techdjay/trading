package com.marketfinance.app.ui.fragments.advancedStockFragment

object MarketStatusReturn {

    val OPEN = "open"
    val CLOSED = "closed"

}