package com.marketfinance.app.utils.network.parser

data class RawLongFMT(
    val raw: Long,
    val fmt: String,
    val longFMT: String
)
