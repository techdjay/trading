package com.marketfinance.app.ui.fragments.advancedStockFragment

import com.robinhood.spark.SparkView

object ChartType {

    /**
     * Uses [SparkView]
     */
    val LineChart = 1

    /**
     *
     */
    val CandleChart = 2

}