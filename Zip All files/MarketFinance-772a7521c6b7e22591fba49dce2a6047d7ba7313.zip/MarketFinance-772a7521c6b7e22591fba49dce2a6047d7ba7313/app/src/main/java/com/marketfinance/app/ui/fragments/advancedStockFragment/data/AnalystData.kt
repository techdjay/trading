package com.marketfinance.app.ui.fragments.advancedStockFragment.data

data class AnalystData(
    val amount: Int,
    val percentage: Int
)
