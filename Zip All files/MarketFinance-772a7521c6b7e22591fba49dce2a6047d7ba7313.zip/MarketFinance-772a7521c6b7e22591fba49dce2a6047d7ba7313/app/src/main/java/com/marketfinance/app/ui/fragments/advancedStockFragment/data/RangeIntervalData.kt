package com.marketfinance.app.ui.fragments.advancedStockFragment.data

data class RangeIntervalData(
    val range: String,
    val interval: String
)