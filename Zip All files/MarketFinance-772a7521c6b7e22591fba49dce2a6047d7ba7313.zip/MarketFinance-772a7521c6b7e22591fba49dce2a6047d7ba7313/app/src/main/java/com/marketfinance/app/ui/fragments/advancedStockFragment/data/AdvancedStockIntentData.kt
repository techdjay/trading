package com.marketfinance.app.ui.fragments.advancedStockFragment.data

data class AdvancedStockIntentData(
    val symbol: String,
    val name: String,
    val quoteType: String
)
