package com.marketfinance.app.utils.network.parser

data class RawFMT(
    val raw: Double?,
    val fmt: String?
)
