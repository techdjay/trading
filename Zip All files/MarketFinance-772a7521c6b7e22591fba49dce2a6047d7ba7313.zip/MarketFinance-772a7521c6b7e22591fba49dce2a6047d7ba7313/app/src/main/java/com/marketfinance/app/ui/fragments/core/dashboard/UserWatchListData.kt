package com.marketfinance.app.ui.fragments.core.dashboard

data class UserWatchListData(
    val listName: String,
    val data: MutableList<WatchListData>
)
