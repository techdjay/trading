package com.marketfinance.app.ui.fragments.advancedStockFragment.data

data class SparkViewData(
    var yData: List<Double>,
    var chartPreviousClose: Double
)
