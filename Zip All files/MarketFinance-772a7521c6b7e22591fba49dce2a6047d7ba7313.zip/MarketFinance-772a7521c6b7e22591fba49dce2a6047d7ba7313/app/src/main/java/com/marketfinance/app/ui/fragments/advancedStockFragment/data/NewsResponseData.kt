package com.marketfinance.app.ui.fragments.advancedStockFragment.data

data class NewsResponseData(
    val title: String,
    val publishDate: String,
    val link: String,
    val content: String,
)
