# Market Finance
Market finance is a privacy focused, paper trading app that uses Yahoo's realtime APIs to simulate transactions

[![Android CI](https://github.com/twango-dev/MarketFinance/actions/workflows/android.yml/badge.svg)](https://github.com/twango-dev/MarketFinance/actions/workflows/android.yml)
