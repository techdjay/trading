# Velocity Trading

Trading Signals software with 5 indicators to start
