from .main import TvDatafeed, Interval
import os, sys; sys.path.append(os.path.dirname(os.path.realpath(__file__)))
__version__ = "1.0.4"
