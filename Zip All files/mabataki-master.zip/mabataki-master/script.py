import time

while True:
	print("I am working!")
	time.sleep(2)
